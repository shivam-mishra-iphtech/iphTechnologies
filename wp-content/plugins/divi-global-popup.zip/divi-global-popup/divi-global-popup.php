<?php
/**
 * Plugin Name: Popup
 * Description: Fullscreen popup with testimonial carousel and form using Bootstrap 5.
 * Version: 1.3
 * Author: Shivam Mishra
 */

add_shortcode('divi_global_popup', 'render_divi_global_popup');
add_action('wp_footer', 'enqueue_divi_popup_assets');

function enqueue_divi_popup_assets() {
    wp_enqueue_style('bootstrap-icons', 'https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css');
    ?>
   <style>
        #divi-global-popup {
            position: fixed;
            top: 0; 
            left: 0;
            width: 100%; 
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 9999;
            padding: 20px;
            opacity: 0;
            transition: opacity 0.3s ease;
            overflow-y: auto;
            margin-top:60px;
        }

        #divi-global-popup.show {
            opacity: 1;
        }

        .popup-main-container {
            max-width: 900px;
            width: 100%;
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .popup-content-container {
            background: #fff;
            border-radius: 12px;
            box-shadow: 0 15px 50px rgba(0, 0, 0, 0.3);
            display: flex;
            flex-direction: column;
            padding: 20px;
            position: relative;
            transform: translateY(20px);
            transition: transform 0.3s ease;
        }

        #divi-global-popup.show .popup-content-container {
            transform: translateY(0);
        }

        .popup-close {
            position: absolute;
            top: 10px;
            right: 10px;
            font-size: 28px;
            color: #666;
            cursor: pointer;
            z-index: 1000;
            transition: all 0.2s ease;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
        }

        .popup-close:hover {
            color: #000;
            background-color: rgba(0,0,0,0.05);
            transform: rotate(90deg);
        }

        /* Improved Testimonial Card Design */
        .testimonial-card {
            background: white;
            border-radius: 12px;
            padding: 30px 20px 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            position: relative;
            height: 100%;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .testimonial-img-container {
            margin-bottom: 15px;
            position: relative;
        }

        .testimonial-img {
            width: 80px;
            height: 80px;
            object-fit: cover;
            border-radius: 50%;
            border: 3px solid #fff;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .testimonial-quote {
            position: relative;
            padding: 0 10px;
            text-align: center;
            flex-grow: 1;
            display: flex;
            flex-direction: column;
        }

        .testimonial-quote::before {
            content: '"';
            font-size: 60px;
            color: rgba(13, 110, 253, 0.1);
            position: absolute;
            top: -20px;
            left: 0;
            line-height: 1;
            font-family: Georgia, serif;
        }

        .bottom-bar {
            background-color: #ffff;
            border-radius: 10px;
            padding: 15px;
            text-align: center;
            font-size: 14px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.08);
            display: flex;
            flex-direction: column;
            width: 100%;
            overflow: hidden;
        }

        .bottom-bar-content {
            width: 100%;
            display: flex;
            flex-direction: column;
        }

        .bottom-bar span {
            font-weight: 600;
        }

        .testimonial-section {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            border-radius: 10px;
            padding: 30px;
            height: 100%;
            position: relative;
        }

        .form-section {
            background: #fff;
            border-radius: 10px;
            padding: 30px;
            height: 100%;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
        }

        .carousel-control-prev, 
        .carousel-control-next {
            width: 40px;
            height: 40px;
            background-color: rgba(0, 0, 0, 0.1);
            border-radius: 50%;
            top: 50%;
            transform: translateY(-50%);
            opacity: 1;
            transition: all 0.3s ease;
        }

        .carousel-control-prev:hover, 
        .carousel-control-next:hover {
            background-color: rgba(0, 0, 0, 0.2);
        }

        .carousel-control-prev {
            left: -20px;
        }

        .carousel-control-next {
            right: -20px;
        }

        ::placeholder {
            padding-left:5px;
            font-size: 14px;
            font-weight: 500;
        }

        .form-control:focus, .form-select:focus {
            border-color: #0d6efd;
            box-shadow: none;
        }

       

        .btn-primary {
            background-color: #0d6efd;
            border: none;
            padding: 12px;
            font-weight: 600;
            border-radius: 8px;
            transition: all 0.3s ease;
            width: 100%;
        }

        .btn-primary:hover {
            background-color: #0b5ed7;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(13, 110, 253, 0.3);
        }

        .invalid-feedback {
            font-size: 13px;
        }

        .stars {
            color: #ffc107;
            font-size: 18px;
            margin-top: 10px;
        }

        .stats-section {
            display: flex;
            flex-direction: column;
            justify-content: center;
            height: 100%;
            margin-bottom: 15px;
        }

        .stats-section p {
            margin-bottom: 5px;
            font-size: 14px;
            white-space: nowrap;
        }

        .marquee-container {
            width: 100%;
            overflow: hidden;
            position: relative;
        }

        .marquee-content {
            display: flex;
            gap: 15px;
            animation: scroll 20s linear infinite;
            width: max-content;
        }

        .award-card {
            background: white;
            border-radius: 8px;
            padding: 10px 15px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            display: flex;
            align-items: center;
            min-width: 200px;
            height: 60px;
            flex-shrink: 0;
        }

        .award-card img {
            height: 40px;
            width: auto;
            margin-right: 10px;
            object-fit: contain;
        }

        .award-card span {
            font-size: 12px;
            font-weight: 600;
        }

        @keyframes scroll {
            0% {
                transform: translateX(0);
            }
            100% {
                transform: translateX(-50%);
            }
        }

        @media (min-width: 768px) {
            .bottom-bar-content {
                flex-direction: row;
                align-items: center;
            }
            
            .stats-section {
                margin-bottom: 0;
                padding-right: 20px;
                border-right: 1px solid #dee2e6;
                margin-right: 20px;
            }
            
            .marquee-container {
                flex: 1;
            }
        }

        @media (max-width: 768px) {
            #divi-global-popup {
                padding: 10px;
                align-items: flex-start;
            }
            
            .popup-main-container {
                margin-top: 60px;
                margin-bottom: 20px;
            }
            
            .popup-content-container {
                padding: 25px 15px;
            }
            
            .bottom-bar {
                gap: 10px;
            }
            
            .testimonial-section, 
            .form-section {
                padding: 20px;
            }

            .carousel-control-prev {
                left: 0;
            }

            .carousel-control-next {
                right: 0;
            }
            
            .stats-section p {
                white-space: normal;
                font-size: 13px;
                text-align: center;
            }
            
            .award-card {
                min-width: 160px;
                padding: 8px 12px;
            }
            
            .testimonial-card {
                padding: 30px 15px 15px;
            }
        }

        @media (max-width: 576px) {
            .popup-content-container {
                padding: 20px 10px;
            }
            
            .bottom-bar {
                padding: 10px;
            }
            
            .bottom-bar span {
                white-space: normal;
                text-align: center;
            }
            
            .testimonial-img {
                width: 70px;
                height: 70px;
            }
            
            .form-section h3 {
                font-size: 1.5rem;
            }
        }
    </style>
    <script>
        function showDiviPopup() {
            const popup = document.getElementById('divi-global-popup');
            popup.style.display = 'flex';
            setTimeout(() => popup.classList.add('show'), 10);
            
            // Store in sessionStorage that popup was shown
            sessionStorage.setItem('diviPopupShown', 'true');
        }
        
        function hideDiviPopup() {
            const popup = document.getElementById('divi-global-popup');
            popup.classList.remove('show');
            setTimeout(() => popup.style.display = 'none', 300);
        }
        
        document.addEventListener('DOMContentLoaded', function() {
            // Only show popup if it hasn't been shown in this session
            if(!sessionStorage.getItem('diviPopupShown')) {
                setTimeout(showDiviPopup, 1000);
            }
            
            // Close when clicking outside content
            document.getElementById('divi-global-popup').addEventListener('click', function(e) {
                if(e.target === this) {
                    hideDiviPopup();
                }
            });
            
            // Escape key closes popup
            document.addEventListener('keydown', function(e) {
                if(e.key === 'Escape') {
                    hideDiviPopup();
                }
            });

            // Initialize Bootstrap Carousel
            const carousel = new bootstrap.Carousel(document.getElementById('testimonialCarousel'), {
                interval: 5000,
                ride: 'carousel'
            });

            // Form validation
            const form = document.querySelector('.needs-validation');
            if (form) {
                form.addEventListener('submit', function(event) {
                    if (!form.checkValidity()) {
                        event.preventDefault();
                        event.stopPropagation();
                    }
                    form.classList.add('was-validated');
                }, false);
            }
        });

        // Exit intent detection
        document.addEventListener('mouseout', function(e) {
            if (!e.relatedTarget && !sessionStorage.getItem('diviPopupShown')) {
                showDiviPopup();
            }
        });
    </script>
    <?php
}

function render_divi_global_popup() {
    ob_start();
    ?>
    <?php  if ( is_user_logged_in() && current_user_can('administrator') ) { ?>
    <div id="divi-global-popup">
        <div class="popup-main-container">
            <div class="popup-content-container">
                <span class="popup-close" onclick="hideDiviPopup()" title="Close">×</span>

                <!-- Main Section -->
                <div class="row g-4">
                    <!-- Testimonial Section -->
                    <div class="col-lg-6">
                        <div class="testimonial-section h-100">
                           
                            
                            <div class="testimonial-content">
                                <h5 class="text-primary fw-bold mb-2">Leaving already?</h5>
                                <p class="mb-4 text-muted">Hear from our clients and why 3000+ businesses trust us</p>

                                <div id="testimonialCarousel" class="carousel slide" data-bs-ride="carousel">
                                    <div class="carousel-inner">
                                        <div class="carousel-item active">
                                            <div class="testimonial-card">
                                                <div class="testimonial-img-container">
                                                    <img src="https://randomuser.me/api/portraits/women/44.jpg" class="testimonial-img" alt="Client 1">
                                                </div>
                                                <div class="testimonial-quote">
                                                    <h6 class="mb-1">Bela Gupta D'Souza</h6>
                                                    <small class="text-muted d-block mb-3">Founder, Edamama</small>
                                                    <p class="text-muted fst-italic">
                                                        "We took a big leap of faith with this company who helped us translate our vision into reality with the perfectly comprehensive eCommerce solution."
                                                    </p>
                                                    <div class="stars">
                                                        <img src="http://localhost/shivam/projects/sourcecode/iphTechnologies/wp-content/uploads/2025/06/rating-star.png" alt="">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="carousel-item">
                                            <div class="testimonial-card">
                                                <div class="testimonial-img-container">
                                                    <img src="https://randomuser.me/api/portraits/men/32.jpg" class="testimonial-img" alt="Client 2">
                                                </div>
                                                <div class="testimonial-quote">
                                                    <h6 class="mb-1">John Smith</h6>
                                                    <small class="text-muted d-block mb-3">CEO, Startup Inc.</small>
                                                    <p class="text-muted fst-italic">
                                                        "Working with this team has been one of the best decisions for our tech growth. Their expertise and dedication are unmatched."
                                                    </p>
                                                    <div class="stars">
                                                        <img src="http://localhost/shivam/projects/sourcecode/iphTechnologies/wp-content/uploads/2025/06/rating-star.png" alt="">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="carousel-item">
                                            <div class="testimonial-card">
                                                <div class="testimonial-img-container">
                                                    <img src="https://randomuser.me/api/portraits/women/68.jpg" class="testimonial-img" alt="Client 3">
                                                </div>
                                                <div class="testimonial-quote">
                                                    <h6 class="mb-1">Sarah Johnson</h6>
                                                    <small class="text-muted d-block mb-3">CTO, TechSolutions</small>
                                                    <p class="text-muted fst-italic">
                                                        "The team delivered our project ahead of schedule and under budget. Their technical expertise saved us months of development time."
                                                    </p>
                                                    <div class="stars">
                                                        <img src="http://localhost/shivam/projects/sourcecode/iphTechnologies/wp-content/uploads/2025/06/rating-star.png" alt="">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <button class="carousel-control-prev" type="button" data-bs-target="#testimonialCarousel" data-bs-slide="prev">
                                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                        <span class="visually-hidden">Previous</span>
                                    </button>
                                    <button class="carousel-control-next" type="button" data-bs-target="#testimonialCarousel" data-bs-slide="next">
                                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                        <span class="visually-hidden">Next</span>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Form Section -->
                    <div class="col-lg-6">
                        <div class="form-section h-100">
                            <h3 class="fw-bold mb-2">Tell us about your project</h3>
                            <p class="text-muted mb-4">We'll provide a free consultation with cost and timeline estimates</p>

                            <form class="needs-validation" novalidate>
                                <div class="row g-3 mb-3">
                                    <div class="col-md-6">
                                        <input type="text" class="form-control py-2 " placeholder="Full Name*" required>
                                        <div class="invalid-feedback">
                                            Please provide your name.
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <input type="email" class="form-control py-2" placeholder="Email*" required>
                                        <div class="invalid-feedback">
                                            Please provide a valid email.
                                        </div>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <textarea class="form-control py-1" rows="2" placeholder="Describe your project/idea in detail*" required></textarea>
                                    <div class="invalid-feedback">
                                        Please describe your project.
                                    </div>
                                </div>

                                <div class="row g-2 mb-3">
                                    <div class="col-4 col-md-3">
                                        <select class="form-select py-2" required>
                                            <option value="" disabled selected>Code</option>
                                            <option value="+91">🇮🇳 +91</option>
                                            <option value="+1">🇺🇸 +1</option>
                                            <option value="+44">🇬🇧 +44</option>
                                        </select>
                                    </div>
                                    <div class="col-8 col-md-9">
                                        <input type="tel" class="form-control py-2" placeholder="Phone Number*" required>
                                        <div class="invalid-feedback">
                                            Please provide your phone number.
                                        </div>
                                    </div>
                                </div>

                                <div class="row g-2 align-items-center mb-4">
                                    <div class="col-3">
                                        <span class="fw-medium">5 + 1 =</span>
                                    </div>
                                    <div class="col-9">
                                        <input type="text" class="form-control py-2" placeholder="Your answer*" required>
                                        <div class="invalid-feedback">
                                            Please solve the simple math.
                                        </div>
                                    </div>
                                </div>

                                <button type="submit" class="btn btn-primary w-100 py-2 fw-bold">
                                    Schedule Free Consultation
                                </button>

                                <div class="mt-4 pt-2 text-center">
                                    <p class="text-muted small mb-2">
                                        <i class="bi bi-shield-lock me-2"></i>Your information is 100% protected by our <strong>NDA</strong>
                                    </p>
                                    <p class="text-muted small">
                                        <i class="bi bi-lightning-charge me-2"></i>Typical response time: <strong>under 2 minutes</strong>
                                    </p>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="bottom-bar">
                <div class="bottom-bar-content">
                    <div class="stats-section">
                        <p><b style="color:#2874fc">1600+</b> transform engineers delivered</p>
                        <p><b style="color:#2874fc">3000+</b> game changing products</p>
                    </div>
                    
                    <div class="marquee-container">
                        <div class="marquee-content">
                            <!-- Duplicate content for seamless looping -->
                            <div class="award-card">
                                <img src="http://localhost/shivam/projects/sourcecode/iphTechnologies/wp-content/uploads/2025/07/bfirms-certified-1.png" alt="Award 1">
                                <span>Businesses Firms</span>
                            </div>
                            <div class="award-card">
                                <img src="http://localhost/shivam/projects/sourcecode/iphTechnologies/wp-content/uploads/2025/07/Top-Mobile-App-Development-Companies-Badge-2024-1-1.png" alt="Award 2">
                                <span>Mobile App Daily</span>
                            </div>
                            <div class="award-card">
                                <img src="http://localhost/shivam/projects/sourcecode/iphTechnologies/wp-content/uploads/2025/07/design-rush-1.png" alt="Award 3">
                                <span>DesignRush</span>
                            </div>
                            <div class="award-card">
                                <img src="http://localhost/shivam/projects/sourcecode/iphTechnologies/wp-content/uploads/2025/07/award4-1-1.png" alt="Award 4">
                                <span>IT Firms</span>
                            </div>
                            <div class="award-card">
                                <img src="http://localhost/shivam/projects/sourcecode/iphTechnologies/wp-content/uploads/2025/07/award2-2-1.png" alt="Award 1">
                                <span>GoodFirms</span>
                            </div>
                            <div class="award-card">
                                <img src="http://localhost/shivam/projects/sourcecode/iphTechnologies/wp-content/uploads/2025/07/award1-1-1.png" alt="Award 2">
                                <span>AppFutura</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
    }
    return ob_get_clean();
}