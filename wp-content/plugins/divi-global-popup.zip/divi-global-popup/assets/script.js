
function showDiviPopup() {
    const popup = document.getElementById('divi-global-popup');
    popup.style.display = 'flex';
    setTimeout(() => popup.classList.add('show'), 10);

    sessionStorage.setItem('diviPopupShown', 'true');
}

function hideDiviPopup() {
    const popup = document.getElementById('divi-global-popup');
    popup.classList.remove('show');
    setTimeout(() => popup.style.display = 'none', 300);
}

document.addEventListener('DOMContentLoaded', function() {
    if (!sessionStorage.getItem('diviPopupShown')) {
        setTimeout(showDiviPopup, 5000);
    }

    const popup = document.getElementById('divi-global-popup');
    if (popup) {
        popup.addEventListener('click', function(e) {
            if (e.target === popup) {
                hideDiviPopup();
            }
        });
    }

    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            hideDiviPopup();
        }
    });

    const carousel = new bootstrap.Carousel(document.getElementById('testimonialCarousel'), {
        interval: 5000,
        ride: 'carousel'
    });
});

// Exit intent detection
document.addEventListener('mouseout', function(e) {
    if (!e.relatedTarget && !sessionStorage.getItem('diviPopupShown')) {
        showDiviPopup();
    }
});
